package com.example.testapp

import android.widget.RadioButton
import core.test.Answer

class AnswerCreator (val multiple:Boolean, val group:MutableList<RadioButton>, val answer:Answer)
